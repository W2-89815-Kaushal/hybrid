let args = process.argv;

var bal = 0;

for(let i=2;i<args.length;i++){
   bal = bal + parseInt(args[i]); 
}

if(bal>0){
    console.log("Balance +"+bal);
}
else{
    console.log("Balance "+bal);
}