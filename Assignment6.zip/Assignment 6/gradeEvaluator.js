let args = process.argv;

for(let i=2;i<args.length;i++){
   let num=parseInt(args[i]);
   if(num==NaN || num>100 || num<0){
	console.log(num+ " = Wrong input");
	continue;
   }
   if(num>95){
	console.log(num+ " = A+");
   }
   else if(num>90){
	console.log(num+ " = A");
   }
   else if(num>85){
	console.log(num +" = B+");
   }
   else if(num>80){
	console.log(num +" = B");
   }
   else if(num>70){
	console.log(num +" = C");
   }
   else if(num>60){
	console.log(num +" = D");
   }
   else if(num<40){
	console.log(num +" = F");
   }
}