let args = process.argv;

let count = parseInt(args[2]);

function counter(){
	function inc(){
	    let i = count+1;
	    console.log("Incremented by 1, "+i);
	}
	inc();

}
counter();

