let args = process.argv;

class Employee{
   constructor(name,id,dept){
      this.name=name;
      this.id=id;
      this.dept=dept;
   }
   printDetails(){
       console.log("Name : "+this.name+" Id : "+this.id+" Department : "+this.dept);
   }
}
let count = 0,e=[],emp=[];
for(let i=2;i<args.length;i++){
    e.push(args[i]);
    count++;
    if(count===3){
        emp.push(new Employee(e[0],e[1],e[2])); 
	e=[];
	count=0;
    }
}

for(let i=0;i<emp.length;i++){
     emp[i].printDetails();
}

