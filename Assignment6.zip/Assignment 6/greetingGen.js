let args = process.argv;

let name = args[2];

let now = new Date();

let hr = now.getHours();

if(hr>12 && hr<18){
   console.log("Good afternoon ☀️ "+name);
}
else if(hr>18 && hr<22){
   console.log("Good evening 🌇 "+name);
}
else if(hr<12 && hr>4){
   console.log("Good morning 🌞 "+name);
}
else{
   console.log("Good night 🌜 "+name);
}