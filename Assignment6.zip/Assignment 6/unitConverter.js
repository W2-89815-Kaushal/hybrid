
   const args = process.argv; 
   for(let i=2; i < args.length; i++) {
	let feet = parseInt(args[i])*3.28084;
	console.log(args[i]+" meter = "+feet+" feet");
	let inches = parseInt(args[i])*39.3701;
	console.log("Inches = "+inches+" inches");
   }

   